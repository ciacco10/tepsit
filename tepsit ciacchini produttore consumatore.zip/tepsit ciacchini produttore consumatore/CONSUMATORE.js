class Consumatore extends Thread {
    private Buffer buffer;
    private int pari = 0;
    private int dispari = 0;

    public Consumatore(Buffer buffer) {
        this.buffer = buffer;
    }

    @Override
    public void run() {
        try {
            while (true) {
                int number = buffer.consume();  // Estrae il numero dal buffer
                if (number % 2 == 0) {
                    pari++;
                } else {
                    dispari++;
                }
                System.out.println("Consumatore ha consumato: " + number);
                System.out.println("Pari: " + pari + ", Dispari: " + dispari);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}