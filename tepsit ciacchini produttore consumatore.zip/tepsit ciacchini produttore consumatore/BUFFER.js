import java.util.Random;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

class Buffer {
    private BlockingQueue<Integer> queue;

    public Buffer(int size) {
        this.queue = new LinkedBlockingQueue<>(size);
    }

    public void produce(int number) throws InterruptedException {
        queue.put(number);  // Inserisce il numero nel buffer (bloccante se pieno)
    }

    public int consume() throws InterruptedException {
        return queue.take();  // Estrae un numero dal buffer (bloccante se vuoto)
    }
}

class Produttore extends Thread {
    private Buffer buffer;
    private Random random = new Random();

    public Produttore(Buffer buffer) {
        this.buffer = buffer;
    }