public class Main {
    public static void main(String[] args) {
        // Chiede i valori T (numero di thread) e N (massimo per i thread che contano)
        java.util.Scanner scanner = new java.util.Scanner(System.in);

        System.out.print("Inserisci il numero di thread T: ");
        int T = scanner.nextInt();  // Numero di thread da creare (produttori e consumatori)

        System.out.print("Inserisci il valore massimo N: ");
        int N = scanner.nextInt();  // Massimo valore che i thread possono contare

        Buffer buffer = new Buffer(10);  // Crea un buffer con capacità 10

        // Crea e avvia i thread produttori e consumatori
        for (int i = 0; i < T; i++) {
            new Produttore(buffer).start();
            new Consumatore(buffer).start();
        }

        // Thread che contano fino a un valore X random tra 0 e N con intervallo 120ms
        for (int i = 0; i < T; i++) {
            new Thread(() -> {
                try {
                    Random rand = new Random();
                    int X = rand.nextInt(N + 1);  // Numero casuale tra 0 e N
                    for (int j = 0; j <= X; j++) {
                        // Conta senza stampare
                        Thread.sleep(120);  // Aspetta 120ms ad ogni incremento
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }).start();
        }
    }
}