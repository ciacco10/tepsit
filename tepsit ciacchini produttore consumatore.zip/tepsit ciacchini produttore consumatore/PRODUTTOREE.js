class Produttore extends Thread {
    private Buffer buffer;
    private Random random = new Random();

    public Produttore(Buffer buffer) {
        this.buffer = buffer;
    }

    @Override
    public void run() {
        try {
            while (true) {
                int number = random.nextInt(1024);  // Genera un numero casuale tra 0 e 1023
                int sleepTime = random.nextInt(901) + 100;  // Intervallo casuale tra 100 e 1000 ms
                buffer.produce(number);  // Inserisce il numero nel buffer
                System.out.println("Produttore ha prodotto: " + number);
                Thread.sleep(sleepTime);  // Pausa prima di produrre un altro numero
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}