package pizzeria;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

class Forno extends Thread {
    private final List<Integer> pizzeProdotte;
    private final int totalePizzeDaProdurre;

    public Forno(List<Integer> pizzeProdotte, int totalePizzeDaProdurre) {
        this.pizzeProdotte = pizzeProdotte;
        this.totalePizzeDaProdurre = totalePizzeDaProdurre;
    }

    @Override
    public void run() {
        Random random = new Random();
        int pizzeProdotteTotali = 0;

        while (pizzeProdotteTotali < totalePizzeDaProdurre) {
            synchronized (pizzeProdotte) {
                int numeroPizze = random.nextInt(8) + 1;

               
                pizzeProdotte.add(numeroPizze);
                pizzeProdotteTotali += numeroPizze;
                System.out.println("Forno ha prodotto " + numeroPizze + " pizze.");

                
                pizzeProdotte.notifyAll();

                
                try {
                    Thread.sleep(1000); 
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
