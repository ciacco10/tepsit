package pizzeria;

class Cameriere extends Thread {
    private final List<Integer> pizzeProdotte;
    private final List<Integer> tavoli;
    private final String nome;
    private final Random random = new Random();

    public Cameriere(String nome, List<Integer> pizzeProdotte, List<Integer> tavoli) {
        this.nome = nome;
        this.pizzeProdotte = pizzeProdotte;
        this.tavoli = tavoli;
    }

    @Override
    public void run() {
        while (true) {
            synchronized (pizzeProdotte) {
                // Se non ci sono pizze disponibili, il cameriere aspetta
                while (pizzeProdotte.isEmpty()) {
                    try {
                        pizzeProdotte.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                // Il cameriere prende le pizze prodotte
                int pizzeDaServire = pizzeProdotte.remove(0);
                System.out.println(nome + " ha preso " + pizzeDaServire + " pizze dal forno.");

                // Simula il servizio delle pizze a un tavolo
                synchronized (tavoli) {
                    if (!tavoli.isEmpty()) {
                        int tavoloServito = tavoli.remove(0);
                        System.out.println(nome + " ha servito " + pizzeDaServire + " pizze al tavolo " + tavoloServito);

                        // Simula il tempo di servizio
                        try {
                            Thread.sleep(random.nextInt(1000) + 500); // da 0.5 a 1.5 secondi
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }
    }
}
