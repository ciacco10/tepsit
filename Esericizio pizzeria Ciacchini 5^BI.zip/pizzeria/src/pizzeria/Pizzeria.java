package pizzeria;

public class Pizzeria {
    public static void main(String[] args) {
        // Lista condivisa per le pizze prodotte
        List<Integer> pizzeProdotte = new ArrayList<>();
        
        // Lista dei tavoli disponibili (fino a 20 tavoli)
        List<Integer> tavoli = new ArrayList<>();
        for (int i = 1; i <= 20; i++) {
            tavoli.add(i);
        }

        // Numero totale di pizze da produrre
        int totalePizzeDaProdurre = 50;

        // Crea il forno e i camerieri
        Forno forno = new Forno(pizzeProdotte, totalePizzeDaProdurre);
        Cameriere cameriere1 = new Cameriere("Cameriere 1", pizzeProdotte, tavoli);
        Cameriere cameriere2 = new Cameriere("Cameriere 2", pizzeProdotte, tavoli);
        Cameriere cameriere3 = new Cameriere("Cameriere 3", pizzeProdotte, tavoli);

        // Avvia il forno e i camerieri
        forno.start();
        cameriere1.start();
        cameriere2.start();
        cameriere3.start();
    }
}
